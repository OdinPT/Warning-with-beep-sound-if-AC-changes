from setuptools import setup

setup(
    name = 'Avisa_modo_bateria',
    version = '0.1',
    description = 'An example of an installable program',
    author = 'OdinPT',
    license = 'GPL',
    entry_points = {'console_scripts': ['prog = Avisa_Bat.py',],},
)
