# Warning-with-beep-sound-if-AC-changes

#Portuguese

Avisa se o tipo de alimentação do notebook for alterada Através de notificação e de audio
preparado unicamente para funcionar em Distros  Gnu/Linux.

#English

Warns you if the notebook's power type is changed Through notification and audio
prepared solely to work in Gnu / Linux Distros.
